package com.mutuelle.mobille.service;

public class AdminService {
}
