package com.mutuelle.mobille.enums;

public enum TransactionDirection {
    CREDIT,
    DEBIT
}