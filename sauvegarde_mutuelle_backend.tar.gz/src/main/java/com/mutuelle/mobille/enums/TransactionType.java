package com.mutuelle.mobille.enums;

public enum TransactionType {
    INSCRIPTION,
    EPARGNE,
    SOLIDARITE,
    EMPRUNT,
    REMBOURSSEMENT,
    RENFOULEMENT,
    INTERET,
    ASSISTANCE,
    AGAPE
}